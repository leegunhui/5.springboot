package com.korea.mBoard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MBoardApplication {

	public static void main(String[] args) {
		SpringApplication.run(MBoardApplication.class, args);
	}

}
