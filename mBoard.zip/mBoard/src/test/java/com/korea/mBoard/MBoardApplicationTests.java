package com.korea.mBoard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
