package com.korea.product2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Product2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
